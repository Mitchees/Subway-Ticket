package Assignment2_000796709;

/**
 * This is the Main Class
 * @author Mitchell Aninyang, 000796709
 */

import java.util.Scanner;

public class SubwayTest extends Thread{
    /**
     *
     * @param args unused
     * @throws InterruptedException
     */
    public static void main(String[] args) throws InterruptedException  {
	// write your code here
        /**
         * This calls the SubwayTicket class and creates an object called ST
         */
        SubwayTicket ST = new SubwayTicket();
        System.out.println("======================================");
        System.out.println("Welcome to the Ticket Counter.");
        System.out.println("======================================");

        Thread.sleep(500);

        /**
         * THIS IS WHAT MAKES THINGS HAPPEN!
         * THIS STATEMENT WILL CALL THE WELCOME METHOD.
         */
        ST.welcome();




        //int welcome = ST.welcome();
        //ST.menu();

        //int menu = ST.menu();
        //ST.menuDecision();






    }


}
