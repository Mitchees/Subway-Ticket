package Assignment2_000796709;
import java.util.Scanner;

/**
 * This is a Subway Ticket Application.
 *
 * @author Mitchell Aninyang, 000796709
 */
public class SubwayTicket {
    /**
     * PRICE FOR A CHILD
     */
    public static final double child = 2.50;
    /**
     * PRICE FOR AN ADULT
     */
    public static final double adult = 5.00;
    /**
     * A QUARTER IS 0.25 CENTS
     */
    public static final double quarter = 0.25;
    /**
     * A LOONIE
     */
    public static final double loonie = 1.00;
    /**
     * A TOONIE
     */
    public static final double toonie = 2.00;
    /**
     * ROUTE I IS HAMILTON
     */
    public static final String route1 = "Hamilton";
    /**
     * ROUTE 2 IS TORONTO
     */
    public static final String route2 = "Toronto";
    /**
     * INITIALISING THE CHOSEN ROUTE TO SHOW THAT
     * USER HAS NOT CHOSEN ANY ROUTES YET.
     */
    public static String chosenRoute = "N/A";
    public static int children = 0;                  //Number of children
    public static int adults = 0;                   //Number of adults
    public static double credits = 0.0;
    public static double amountDue = 0.0;
    /**
     * Declared a public Static Scanner so that it can be accessible
     * to all the classes in this place.
     */
    public static Scanner in = new Scanner(System.in);

    public static void checkout() throws InterruptedException {
        System.out.println("===========  TICKET DETAILS  ============");
        ticketDetails();
        System.out.println("\n 1) Proceed to checkout\n 2) Make changes");
        System.out.print("Your Choice: ");
        int checkoutOption = in.nextInt();
        switch (checkoutOption){
            case 1:
                clearScreen();
                welcome();
                break;
            case 2:
                clearScreen();
                menuHeader();
                break;
            default:
                clearScreen();
                System.out.println("INVALID SELECTION!!");
                checkout();
                break;
        }
    }
    /**
     * My Welcome Menu Buttons
     * @throws InterruptedException
     * @return Welcome Choice
     */

    public static int welcome() throws InterruptedException{
        System.out.println("1) Approach First Machine");
        Thread.sleep(500);
        System.out.println("2) Approach Second Machine");
        Thread.sleep(500);
        System.out.println("3) Exit\n");
        Thread.sleep(500);
        System.out.print("Your Choice: ");

        //INPUT CHOICE FROM WELCOME MENU
        int welcomeChoice = in.nextInt();
        //SWITCH CASE FOR WELCOME MENU POSSIBLE CHOICES
        switch (welcomeChoice) {
            case 1:
                clearScreen();
                menuHeader();
                break;
            case 2:
                clearScreen();
                menuHeader();
                break;
            case 3:
                System.out.println("Bye!!");
                break;
            default:
                System.out.println("Invalid Selection!!");
                welcome();                    //THIS BASICALLY MAKES THE METHOD RUN AGAIN. ITS A FORM OF LOOP
                break;
        }
        return welcomeChoice;

    }

    /**
     * Method to show the end of the program
     */
    public static void end(){
        System.out.println("END");
    }

    /**
     * METHOD FOR CLEARING SCREEN
     */

    public static void clearScreen(){
        for (int clear = 0; clear < 100; clear ++){
            System.out.println();
        }
    }

    /**
     * Menu Header
     * This is where all information about the ticket is shown.
     */
    public static void menuHeader() throws InterruptedException{

        System.out.println("-----------------------------------------------------");
        System.out.printf("Selected Route: %s \tChild: $%.1f \tAdult: $%.1f\nChildren: %d " +
                        "\tAdults: %d\nCredits: %.1f\t Amount due: %.1f\n" +
                        "",
                chosenRoute, child, adult, children, adults, credits, amountDue);
        System.out.println("-----------------------------------------------------");
        menu();
    }

    /**
     * Ticket Details
     * This is where all information about the ticket is shown.
     * this is basically a copy of the menuHeader() method without the ability to call the menu() method
     */

    public static void ticketDetails(){

        System.out.println("-----------------------------------------------------");
        System.out.printf("Selected Route: %s \tChild: $%.1f \tAdult: $%.1f\nChildren: %d " +
                        "\tAdults: %d\nCredits: %.1f\t Amount due: %.1f\n" +
                        "",
                chosenRoute, child, adult, children, adults, credits, amountDue);
        System.out.println("-----------------------------------------------------");
    }

    /**
     * METHOD FOR DISPLAYING THE MENU
     */

    public static int menu() throws InterruptedException {
        System.out.printf("1) Select Route '%s'\n", route1);
        System.out.printf("2) Select Route '%s'\n", route2);
        System.out.println("3) Add Adult");
        System.out.println("4) Remove Adult");
        System.out.println("5) Add Child");
        System.out.println("6) Remove Child");
        System.out.println("7) Insert Quarter");
        System.out.println("8) Insert Loonie");
        System.out.println("9) Insert Toonie");
        System.out.println("10) Print Ticket");
        System.out.println("11) Step Away From Machine\n");
        System.out.print("Your Choice: ");

        //INPUT MENU CHOICE
        int menuChoice = in.nextInt();
        /**
         * this block checks of menu choice is either  10 or 11
         * if so, the program exits the loop. Else, the program Joins the loop.
         */
        if (menuChoice != 11 && menuChoice != 10) {
            while (menuChoice != 11 && menuChoice != 10) {
                switch (menuChoice) {
                    case 1:
                        chosenRoute = route1;
                        clearScreen();
                        menuHeader();
                        break;
                    case 2:
                        chosenRoute = route2;
                        clearScreen();
                        menuHeader();
                        break;
                    case 3:
                        adults += 1;
                        amountDue += adult;
                        clearScreen();
                        menuHeader();
                        break;
                    case 4:
                        adults -= adults;
                        amountDue -= adult;
                        clearScreen();
                        menuHeader();
                        break;
                    case 5:
                        children += 1;
                        amountDue += child;
                        clearScreen();
                        menuHeader();
                        break;
                    case 6:
                        if (children == 0 || children < 1) {
                            clearScreen();
                            System.out.println("There are no Children!");
                            menuHeader();
                        } else if (children >= 1 && amountDue < 0) {
                            children -= 1;
                            amountDue += child;
                            clearScreen();
                            menuHeader();
                        } else if (amountDue > 0) {
                            children -= 1;
                            amountDue -= child;
                            clearScreen();
                            menuHeader();
                        }
                        break;
                    case 7:
                        credits += quarter;
                        amountDue -= quarter;
                        clearScreen();
                        menuHeader();
                        break;
                    case 8:
                        credits += loonie;
                        amountDue -= loonie;
                        clearScreen();
                        menuHeader();
                        break;
                    case 9:
                        credits += toonie;
                        amountDue -= toonie;
                        clearScreen();
                        menuHeader();
                        break;
                    case 10:
                        if (amountDue > 1) {
                            clearScreen();
                            System.out.println("YOU CAN'T HAVE YOUR TICKET UNTIL YOU COMPLETE PAYMENT!!");
                            menuHeader();
                        } else {
                            checkout();
                            break;
                        }
                        break;
                    case 11:
                        welcome();
                        break;
                    default:
                        System.out.println("INVALID SELECTION!!");
                        break;
                }
            }
        } else {
            /**
             * THis will go to the check outj method because
             * the menu choice was either 10 or 11
             */
            checkout();
        }
        return menuChoice;
    }
}
